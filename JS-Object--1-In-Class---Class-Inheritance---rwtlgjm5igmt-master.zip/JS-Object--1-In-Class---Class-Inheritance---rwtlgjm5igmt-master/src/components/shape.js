
// declare class

class Shape {
    constructor() {
         this.color = "green";
    }
    drawShape() {

    }
    calculateArea() {

    }
}
// export class using module.exports
module.exports = Shape;
// export class using module.exports
